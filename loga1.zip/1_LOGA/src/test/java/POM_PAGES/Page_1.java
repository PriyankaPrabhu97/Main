package POM_PAGES;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import BASE_CLASSes.Wait;

public class Page_1 {
	
	WebDriver dr;
	Wait wt;
	
	public Page_1(WebDriver dr) 
	{
		this.dr = dr;
		wt = new Wait(dr);	
	}
	
	public void women()
	{		
		By wmn =By.xpath("//a[@title='Women']");
		WebElement wt_wmn=wt.elementToBeClickable(wmn, 20);
		wt_wmn.click();
	}

}
