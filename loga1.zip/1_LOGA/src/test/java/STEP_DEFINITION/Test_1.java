package STEP_DEFINITION;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import BASE_CLASSes.Browsers;
import BASE_CLASSes.Wait;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Test_1 {
	
	WebDriver dr;
	Browsers Br;
	Wait wt;
	
	String URL = "http://automationpractice.com/index.php";
	
	@Given("^Browser is launched & products are displayed$")
	public void browser_is_launched_products_are_displayed() throws Throwable {		
		System.out.println("browser_is_launched_products_are_displayed");
		Br = new Browsers(dr);
		Br.Launch("Chrome", URL);    
	}

	@When("^Click on add to cart$")
	public void click_on_add_to_cart() throws Throwable {		
		System.out.println("click_on_add_to_cart");
		dr.findElement(By.xpath("//a[@title='Women']")).click();
	}

	@Then("^Succefully add products to cart$")
	public void succefully_add_products_to_cart() throws Throwable {		
		System.out.println("succefully_add_products_to_cart");
	    
	}

}
