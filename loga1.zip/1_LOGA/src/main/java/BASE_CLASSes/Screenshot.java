package BASE_CLASSes;

public class Screenshot {

}
