package BASE_CLASSes;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Browsers {
	
	WebDriver dr;
	public Browsers(WebDriver dr)
	{
		this.dr = dr;
	}
	
	//To browser either chrome or firefox
	public WebDriver Launch(String browser, String URL)
	{
		//Pass options to chromedriver
		if(browser.contains("Chrome"))
		{		
			System.setProperty("webdriver.chrome.driver", "src\\test\\resources\\DRIVERS\\chromedriver.exe");
			dr = new ChromeDriver();
			System.out.println("Running in chrome browser");
		}
		//Pass options to geckodriver
		else if(browser.contains("Firefox"))
		{
			System.setProperty("webdriver.gecko.driver", "src\\test\\resources\\DRIVERS\\geckodriver.exe");
			dr = new FirefoxDriver();
			System.out.println("Running in firefox browser");
		}
		//Navigate to URL site
		dr.get(URL);
		dr.manage().window().maximize();
		dr.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
		return dr;
	}

}
