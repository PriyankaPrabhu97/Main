package Base_Class;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Browsers {
	
	WebDriver dr;
	public Browsers(WebDriver dr)
	{
		this.dr = dr;
	}
	
	public WebDriver Launch(String browser, String URL)
	{
		if(browser.contains("Chrome"))
		{		
			System.setProperty("webdriver.chrome.driver", "Drivers\\chromedriver.exe");
			dr = new ChromeDriver();
			System.out.println("Running in chrome browser");
		}
		else if(browser.contains("Firefox"))
		{
			System.setProperty("webdriver.gecko.driver", "Drivers\\geckodriver.exe");
			dr = new FirefoxDriver();
			System.out.println("Running in firefox browser");
		}
		dr.get(URL);
		dr.manage().window().maximize();
		dr.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
		return dr;
	}


}
